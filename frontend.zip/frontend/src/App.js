import React from 'react';
import UsuarioList from './components/UsuarioList';

function App() {
  return (
    <div className="App">
      <UsuarioList />
    </div>
  );
}

export default App;
