import React, { useEffect, useState } from 'react';
import axios from 'axios';

const UsuarioList = () => {
  const [usuarios, setUsuarios] = useState([]);
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');

  useEffect(() => {
    axios.get('http://localhost:8080/api/usuarios')
      .then(response => setUsuarios(response.data))
      .catch(error => console.error('Erro ao buscar usuários:', error));
  }, []);

  const adicionarUsuario = () => {
    axios.post('http://localhost:8080/api/usuarios', { nome, email })
      .then(response => setUsuarios([...usuarios, response.data]))
      .catch(error => console.error('Erro ao adicionar usuário:', error));
  };

  const deletarUsuario = (id) => {
    axios.delete(`http://localhost:8080/api/usuarios/${id}`)
      .then(() => setUsuarios(usuarios.filter(usuario => usuario.id !== id)))
      .catch(error => console.error('Erro ao deletar usuário:', error));
  };

  return (
    <div>
      <h1>Usuários</h1>
      <ul>
        {usuarios.map(usuario => (
          <li key={usuario.id}>
            {usuario.nome} ({usuario.email})
            <button onClick={() => deletarUsuario(usuario.id)}>Deletar</button>
          </li>
        ))}
      </ul>
      <h2>Adicionar Usuário</h2>
      <input
        type="text"
        placeholder="Nome"
        value={nome}
        onChange={e => setNome(e.target.value)}
      />
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={e => setEmail(e.target.value)}
      />
      <button onClick={adicionarUsuario}>Adicionar</button>
    </div>
  );
};

export default UsuarioList;
